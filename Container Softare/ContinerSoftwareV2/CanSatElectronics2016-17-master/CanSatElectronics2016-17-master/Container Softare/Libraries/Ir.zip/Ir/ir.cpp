#include "Arduino.h"
#include "Ir.h"

Ir::Ir(int pin){
	pinMode(pin, INPUT);
	_pin = pin;
}

bool Ir::status(){
	int val = analogRead(_pin);
	if(val<70){
		return false;
	}else{
		return true;
	}
}