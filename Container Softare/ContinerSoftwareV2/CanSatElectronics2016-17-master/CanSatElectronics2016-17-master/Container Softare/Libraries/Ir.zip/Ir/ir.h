/*
	ir.h - Library for ir photogate
	Create by Dan Stingaciu, May 9, 2017
	Use for CANSAT
*/
#ifndef Ir_h
#define Ir_h

#include "Arduino.h"

class Ir{
	public:
		Ir(int pin);
		bool status();
		int val;
	private:
		int _pin;
};

#endif